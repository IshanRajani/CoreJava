<?php
require_once "controller/StudentController.php";

$controller = new StudentController();
$students = $controller->fetchStudents();

require_once "view/studentView.php";
?>
