<!DOCTYPE html>
<html>
<head>
    <title>Student Data</title>

    <!-- ✅ jQuery CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- ✅ DataTables CSS + JS CDN -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

    <style>
        body { font-family: Arial, sans-serif; }
        h2 { text-align: center; margin-bottom: 20px; color: #2c3e50; }
        .container { width: 90%; margin: auto; }

        table.dataTable thead th {
            background-color: #34495e;
            color: white;
        }

        table.dataTable tbody tr:hover {
            background-color: #f1f1f1;
        }

        #studentTable_wrapper {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Student Records</h2>

    <table id="studentTable" class="display">
        <thead>
            <tr>
                <?php
                if (!empty($students)) {
                    foreach(array_keys($students[0]) as $columnName) {
                        echo "<th>" . htmlspecialchars($columnName) . "</th>";
                    }
                }
                ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach($students as $student): ?>
                <tr>
                    <?php foreach($student as $value): ?>
                        <td><?= htmlspecialchars($value) ?></td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- ✅ DataTables Initialization Script -->
<script>
    $(document).ready(function() {
        $('#studentTable').DataTable({
            "paging": true,
            "searching": true,
            "info": true,
            "ordering": true
        });
    });
</script>

</body>
</html>
