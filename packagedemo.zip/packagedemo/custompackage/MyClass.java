// File: custompackage/MyClass.java
package custompackage;

public class MyClass {
    public void display() {
        System.out.println("Hello from MyClass!");
    }
}
