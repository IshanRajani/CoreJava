<?php
require_once __DIR__ . '/../model/StudentModel.php';

class StudentController {
    private $model;

    public function __construct() {
        $this->model = new StudentModel();
    }

    public function fetchStudents() {
        return $this->model->getAllStudents();
    }
}
?>
