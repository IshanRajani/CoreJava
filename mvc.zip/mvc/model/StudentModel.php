<?php
class StudentModel {
    private $conn;

    public function __construct() {
        $this->conn = new mysqli("localhost", "root", "", "gsfc_db");

        if ($this->conn->connect_error) {
            die("Database Connection Failed: " . $this->conn->connect_error);
        }
    }

    public function getAllStudents() {
        $sql = "SELECT * FROM student";
        $result = $this->conn->query($sql);
        $students = [];

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $students[] = $row;
            }
        }

        return $students;
    }
}
?>
